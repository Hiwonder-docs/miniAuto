/**
 * @file clear_roadblock.ino
 * @author Anonymity(Anonymity@hiwonder.com)
 * @brief APP遥控玩法
 * @version V1.0
 * @date 2024-07-25
 *
 * @copyright Copyright (c) 2024
 *
 * @attention main函数中不可以做任何阻塞处理！
 */

#include "MultiTimer.h"
#include "Motor.h"
#include "hw_esp32s3cam_ctl.h"
#include "Tracking_Calculation.h"
#include "Ultrasound.h"
#include <Servo.h>

Timers timer1;
Timers timer2;
Timers timer3;
Timers timer4;

Servo myServo;
HW_ESP32S3CAM hw_cam;
Ultrasound ultrasound;  

/* 引脚定义 */
const static uint8_t servoPin = 5;

const static uint8_t target_point = 80;


static uint16_t set_angle = 0;
static int8_t set_rot = 0;
static int8_t set_speed = 0;

static uint8_t time_count = 0;

/* 丢线时校准参数 */
static uint8_t first_calibration_data;
static uint8_t second_calibration_data;

/* 巡线坐标参数 */
static uint8_t first_block_data[DATA_ARRAY_COUNT];
static uint8_t second_block_data[DATA_ARRAY_COUNT];

/* 障碍物坐标参数 */
static uint8_t roadblock_first_block_data[DATA_ARRAY_COUNT];
static uint8_t roadblock_second_block_data[DATA_ARRAY_COUNT];

void set_servo(uint8_t angle)
{
  myServo.write(angle);
}

/* 获取基准时间 */
uint32_t ticksGetFunc(void)
{
  return micros();
}

/* 每60ms进行位置坐标计算 */
void timerPIDCalculateCallBack(Timers *ptimer, const void *userdata)
{
  int bias_average;
  /* 寻线坐标参数获取 */
  hw_cam.Region1_Red_Block_Detection(first_block_data, sizeof(first_block_data));
  hw_cam.Region2_Red_Block_Detection(second_block_data, sizeof(second_block_data));

  /* 障碍物坐标参数获取 */
  hw_cam.Region1_Green_Block_Detection(roadblock_first_block_data, sizeof(roadblock_first_block_data));
  hw_cam.Region2_Green_Block_Detection(roadblock_second_block_data, sizeof(roadblock_second_block_data));
  
  /* 计算x轴偏移均值 */
  bias_average = (first_block_data[0] + second_block_data[0]) / 2;

  if(first_block_data[0] != 0 && second_block_data[0] != 0 && 
     roadblock_first_block_data[0] == 0 && roadblock_second_block_data[0] == 0) 
  {
    set_speed = 50;
    Position_Control(&bias_average, &set_rot, &target_point);
    timerStart(ptimer, 60000, timerPIDCalculateCallBack, userdata);
    first_calibration_data = first_block_data[0];   /* 记录色块位置，丢线时做判断处理 */
    second_calibration_data = second_block_data[0];
  }
  else if(roadblock_first_block_data[0] != 0)   /* 若看到障碍物就停止巡线 */
  {
    timerStop(ptimer);
    timerStart(&timer2, 100000, timerMovingRoadblockCallBack, "100ms cycle moving_roadblock");
  }
  /* 若偏离程度过大，开启丢线位置矫正定时器回调，关闭PID计算定时器回调 */
  else if(first_block_data[0] == 0 || second_block_data[0] == 0)  
  {
    set_speed = 0;
    set_rot = 0;
    timerStop(ptimer);
    timerStart(&timer3, 60000, timerPositionCalibrationCallBack, "60ms cycle position calibration");
  }
}

/*清除障碍物定时器回调*/
void timerMovingRoadblockCallBack(Timers *ptimer, const void *userdata)
{
  hw_cam.Region1_Red_Block_Detection(first_block_data, sizeof(first_block_data));
  switch(time_count) 
  {
  case 0:
    set_angle = 0;
    set_speed = 30;
    set_rot = 0;   
    break;
  case 5:
    set_servo(0+90);
    set_speed = 0;
    set_rot = 60;
    break;
  case 10:
    set_angle = 0;
    set_speed = 0;
    set_rot = 0;
    break;
  case 17:
    set_angle = 0;
    set_speed = 50;
    set_rot = 0;
    break;
  case 20:
    set_servo(60+90);
    set_angle = 0;
    set_speed = 0;
    set_rot = 0;
    break;
  case 30:
    set_angle = 180;
    set_speed = 30;
    set_rot = -30;
    break;
  }
  if(time_count >= 30)
  {
    /* 识别到线条色块就继续巡线 */
    if(first_block_data[0] != 0)
    {   
      set_angle = 0;
      set_speed = 0;
      set_rot = 0;
      time_count = 0;
      timerStop(ptimer);
      timerStart(&timer1, 60000, timerPIDCalculateCallBack, "60ms cycle PID calculate");
    }
    else
    {
      time_count++;
      timerStart(ptimer, 100000, timerMovingRoadblockCallBack, userdata);  
    }
  }
  else
  {
    time_count++;
    timerStart(ptimer, 100000, timerMovingRoadblockCallBack, userdata);  
  }
}

/* 丢线处理定时器回调 */
void timerPositionCalibrationCallBack(Timers *ptimer, const void *userdata)
{
  hw_cam.Region1_Red_Block_Detection(first_block_data, sizeof(first_block_data));
  hw_cam.Region2_Red_Block_Detection(second_block_data, sizeof(second_block_data));
  if(first_block_data[0] != 0 && second_block_data[0] != 0)
  {
    timerStop(ptimer);
    timerStart(&timer1, 60000, timerPIDCalculateCallBack, userdata);
  }
  else
  {
    if(first_calibration_data >= 80 || second_calibration_data >= 80)
    {
      set_angle = 0;
      set_speed = 40;
      set_rot = -15;
    }
    else if(first_calibration_data < 80 || second_calibration_data < 80)
    {
      set_angle = 0;
      set_speed = 40;
      set_rot = 15;
    }
    timerStart(ptimer, 60000, timerPositionCalibrationCallBack, userdata);

  }
}

void setup() {
  Serial.begin(115200);
  ticksFuncSet(ticksGetFunc);
  Motors_Initialize();
  hw_cam.begin();
  Calculation_Init();
  myServo.attach(servoPin);
  set_servo(60+90);
  delay(500);
  ultrasound.Color(0,0,0,0,0,0);
  timerStart(&timer1, 60000, timerPIDCalculateCallBack, "60ms cycle PID calculate");
}

void loop() {
  /* 定时器任务运行 */
  timersTaskRunning();
  /* 软件PWM驱动电机进行姿态调整 */
  Velocity_Controller(set_angle, set_speed, set_rot, SIMULATE_PWM_CONTROL);
}


