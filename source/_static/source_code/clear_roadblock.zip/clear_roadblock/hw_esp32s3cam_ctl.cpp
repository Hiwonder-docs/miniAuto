#include "hw_esp32s3cam_ctl.h"

static bool Wire_Write_Data_Array(uint8_t addr,
                                  uint8_t reg,
                                  uint8_t *val, 
                                  uint16_t len)
{
   uint16_t i;
    Wire.beginTransmission(addr);
    Wire.write(reg);
    for(i = 0; i < len; i++) 
    {
        Wire.write(val[i]);
    }
    if( Wire.endTransmission() != 0 ) 
    {
        return false;
    }
    return true;
}

static bool Wire_Write_Byte(uint8_t val)
{
    Wire.beginTransmission(ESP32S3_ADDR);
    Wire.write(val);
    if( Wire.endTransmission() != 0 ) {
        return false;
    }
    return true;
}

static int Wire_Read_Data_Array(uint8_t reg, 
                                uint8_t *val, 
                                uint16_t len)
{
    uint16_t i = 0;
    
    /* Indicate which register we want to read from */
    if (!Wire_Write_Byte(reg)) {
        return -1;
    }
    
    /* Read block data */
    Wire.requestFrom(ESP32S3_ADDR, len);
    while (Wire.available()) {
        if (i >= len) {
            return -1;
        }
        val[i] = Wire.read();
        i++;
    }   
    return i;
}

void HW_ESP32S3CAM::begin()
{
    Wire.setClock(100000);
    Wire.begin();
}

uint16_t HW_ESP32S3CAM::Region1_Red_Block_Detection(uint8_t *buf, uint8_t buf_len)
{
    return Wire_Read_Data_Array(LINE_FOLLOWING_FIRST_COLOR_REG1, buf, buf_len);
}

uint16_t HW_ESP32S3CAM::Region2_Red_Block_Detection(uint8_t *buf, uint8_t buf_len)
{
    return Wire_Read_Data_Array(LINE_FOLLOWING_FIRST_COLOR_REG2, buf, buf_len);
}

uint16_t HW_ESP32S3CAM::Region1_Green_Block_Detection(uint8_t *buf, uint8_t buf_len)
{
    return Wire_Read_Data_Array(LINE_FOLLOWING_SECOND_COLOR_REG1, buf, buf_len);
}

uint16_t HW_ESP32S3CAM::Region2_Green_Block_Detection(uint8_t *buf, uint8_t buf_len)
{
    return Wire_Read_Data_Array(LINE_FOLLOWING_SECOND_COLOR_REG2, buf, buf_len);
}

uint16_t HW_ESP32S3CAM::Region1_Blue_Block_Detection(uint8_t *buf, uint8_t buf_len)
{
    return Wire_Read_Data_Array(LINE_FOLLOWING_THIRD_COLOR_REG1, buf, buf_len);
}

uint16_t HW_ESP32S3CAM::Region2_Blue_Block_Detection(uint8_t *buf, uint8_t buf_len)
{
    return Wire_Read_Data_Array(LINE_FOLLOWING_THIRD_COLOR_REG2, buf, buf_len);
}

uint16_t HW_ESP32S3CAM::Region1_Purple_Block_Detection(uint8_t *buf, uint8_t buf_len)
{
    return Wire_Read_Data_Array(LINE_FOLLOWING_FOURTH_COLOR_REG1, buf, buf_len);
}

uint16_t HW_ESP32S3CAM::Region2_Purple_Block_Detection(uint8_t *buf, uint8_t buf_len)
{
    return Wire_Read_Data_Array(LINE_FOLLOWING_FOURTH_COLOR_REG2, buf, buf_len);
}

uint16_t HW_ESP32S3CAM::Face_Data_Receive(uint8_t *buf, uint8_t buf_len)
{
    return Wire_Read_Data_Array(FACE_DETECTION_REG, buf, buf_len);
}

uint16_t HW_ESP32S3CAM::Red_Block_Detection(uint8_t *buf, uint8_t buf_len)
{
    return Wire_Read_Data_Array(COLOR_DETECTION_FIRST_COLOR_REG, buf, buf_len);
}

uint16_t HW_ESP32S3CAM::Green_Block_Detection(uint8_t *buf, uint8_t buf_len)
{
    return Wire_Read_Data_Array(COLOR_DETECTION_SECOND_COLOR_REG, buf, buf_len);
}

uint16_t HW_ESP32S3CAM::Blue_Block_Detection(uint8_t *buf, uint8_t buf_len)
{
    return Wire_Read_Data_Array(COLOR_DETECTION_THIRD_COLOR_REG, buf, buf_len);
}

uint16_t HW_ESP32S3CAM::Purple_Block_Detection(uint8_t *buf, uint8_t buf_len)
{
    return Wire_Read_Data_Array(COLOR_DETECTION_FOURTH_COLOR_REG, buf, buf_len);
}

uint16_t HW_ESP32S3CAM::Color_ID_Detection(uint8_t *buf, uint8_t buf_len)
{
    return Wire_Read_Data_Array(COLOR_DETECTION_ID_REG, buf, buf_len);
}

