#ifndef __HW_ESP32CAM_CTL_H_
#define __HW_ESP32CAM_CTL_H_

#include <Arduino.h>
#include <Wire.h>

#define ESP32S3_ADDR 0x52
#define DATA_ARRAY_COUNT 4

/*line following data reg*/
#define LINE_FOLLOWING_FIRST_COLOR_REG1 0xA0
#define LINE_FOLLOWING_FIRST_COLOR_REG2 0xA1
#define LINE_FOLLOWING_SECOND_COLOR_REG1 0xA2
#define LINE_FOLLOWING_SECOND_COLOR_REG2 0xA3
#define LINE_FOLLOWING_THIRD_COLOR_REG1 0xA4
#define LINE_FOLLOWING_THIRD_COLOR_REG2 0xA5
#define LINE_FOLLOWING_FOURTH_COLOR_REG1 0xA6
#define LINE_FOLLOWING_FOURTH_COLOR_REG2 0xA7

/*face detection data reg*/
#define FACE_DETECTION_REG 0x01

/*color detection data reg*/
#define COLOR_DETECTION_FIRST_COLOR_REG 0x00
#define COLOR_DETECTION_SECOND_COLOR_REG 0x01
#define COLOR_DETECTION_THIRD_COLOR_REG 0x02
#define COLOR_DETECTION_FOURTH_COLOR_REG 0x03
#define COLOR_DETECTION_ID_REG 0x04

class HW_ESP32S3CAM
{
public:
    void begin(void);
    uint16_t Region1_Red_Block_Detection(uint8_t *buf, uint8_t buf_len);
    uint16_t Region2_Red_Block_Detection(uint8_t *buf, uint8_t buf_len);
    uint16_t Region1_Green_Block_Detection(uint8_t *buf, uint8_t buf_len);
    uint16_t Region2_Green_Block_Detection(uint8_t *buf, uint8_t buf_len);
    uint16_t Region1_Blue_Block_Detection(uint8_t *buf, uint8_t buf_len);
    uint16_t Region2_Blue_Block_Detection(uint8_t *buf, uint8_t buf_len);
    uint16_t Region1_Purple_Block_Detection(uint8_t *buf, uint8_t buf_len);
    uint16_t Region2_Purple_Block_Detection(uint8_t *buf, uint8_t buf_len);
    uint16_t Face_Data_Receive(uint8_t *buf, uint8_t buf_len);
    uint16_t Red_Block_Detection(uint8_t *buf, uint8_t buf_len);
    uint16_t Green_Block_Detection(uint8_t *buf, uint8_t buf_len);
    uint16_t Blue_Block_Detection(uint8_t *buf, uint8_t buf_len);
    uint16_t Purple_Block_Detection(uint8_t *buf, uint8_t buf_len);
    uint16_t Color_ID_Detection(uint8_t *buf, uint8_t buf_len);
};

#endif