#include "MultiTimer.h"
#include "stdio.h"


static Timers *pTimerList = NULL;
//记录各个定时器的定时器列表
//各个定时器的排布/存放原则：按各个定时器下一次被触发的系统时间排布（越早被触发的越靠前，使得可以被系统及时遍历到，处理其触发事件）
static PlatformTicksFunction_t platFormTicksFunction = NULL;

//将用户传入的函数ticksFunc与我们自定义的platFormTicksFunction函数绑定
//每次执行platFormTicksFunction，等效于执行ticksFunc
int ticksFuncSet(PlatformTicksFunction_t ticksFunc)
{
  platFormTicksFunction = ticksFunc;
  if(platFormTicksFunction == NULL)
  {
    return -1;
  }
  else
  {
    return 1;
  }
}

int timerStart(Timers *ptimer, uint32_t timing, TimersCallback_t timersCallBack, const void *userdata)
{
  if (!ptimer || !timersCallBack)
  //判断定时器与回调函数是否有效（已被预先定义）
  {
    // _LOG("Timer initalize error.");
    return -1;    
  }
  //将定时器列表pTimerList的地址赋给pNextTimer
  Timers **pNextTimer = &pTimerList;

  //遍历定时器列表的上记录的各个定时器，直到最后一个
  for (; *pNextTimer; pNextTimer = &(*pNextTimer)->next)
  {
    //如果在定时器列表中找到了参数传入的定时器（该定时器已经预先记录到定时器列表中），则先将当前定时器移除
    if(ptimer == *pNextTimer)
    {
      /*原先逻辑：a->next= ptimer
            ptimer->next=b   (定时器先后顺序：a-ptimer-b)
        操作逻辑：a->next=ptimer->next（也就是b）
        操作后逻辑：a->next=b  （定时器先后顺序：a-b）(ptimer从定时器列表中移除)
      */
      *pNextTimer = ptimer->next;  
      break;
    }
  }

  ptimer->deadline = platFormTicksFunction() + timing;
  //platFormTicksFunction()得到当前系统定时  timing记录定时持续时间    deadline为下一次定时器到点的时候的系统时间
  ptimer->timersCallBack = timersCallBack;  //绑定定时器触发的回调函数
  ptimer->userdata = userdata;  //绑定用户自定义数据
  //遍历定时器列表的上记录的各个定时器，直到最后一个
  //遍历
  for (pNextTimer = &pTimerList;; pNextTimer = &(*pNextTimer)->next)
  {
    //如果遍历到了列表的结尾（说明该定时器的下一次触发时间是最晚的），则将定时器追加记录到定时器列表的最后
    if (!*pNextTimer)
    {
      ptimer->next = NULL;
      *pNextTimer = ptimer;
      break;
    }
    //按各个定时器下一次被触发的系统时间插入当前传入的定时器，按下一次触发时间由早到晚的顺序排布定时器
    if (ptimer->deadline < (*pNextTimer)->deadline)
    {
      ptimer->next = *pNextTimer;
      *pNextTimer = ptimer;
      break;
    }
  }
  return 1;
}

//关闭当前定时器（将当前定时器从定时器列表中移除出去）
int timerStop(Timers *ptimer)
{
  Timers **pNextTimer = &pTimerList;
  for (; *pNextTimer; pNextTimer = &(*pNextTimer)->next)
  {
    Timers *entry = pTimerList;
    if(entry == ptimer)
    {
        /*原先逻辑：a->next= ptimer
        ptimer->next=b   (定时器先后顺序：a-ptimer-b)
        操作逻辑：a->next=ptimer->next（也就是b）
        操作后逻辑：a->next=b  （定时器先后顺序：a-b）(ptimer从定时器列表中移除)
      */
      *pNextTimer = ptimer->next;
      break;
    }
  }
  return 1;
}

int timersTaskRunning(void)
{
  //将定时器列表pTimerList（注：定时器列表内各个定时器按下一次触发时间的早晚顺序排布）的地址赋给entry   
  Timers *entry = pTimerList;
  //遍历访问定时器列表的每一个定时器
  for (; entry; entry = entry->next)
  {
    /*如果当前定时器的下一次触发时间晚于当前系统时间（排在后面的定时器
      自然也还没到下一次被触发的时间），则退出函数，结束遍历*/
    if (platFormTicksFunction() < entry->deadline)
    {
      return (int)(entry->deadline - platFormTicksFunction());
    }

    //如果当前定时器到点被触发，则先将该定时器从定时器列表中移除，再执行当前定时器的触发回调函数
    pTimerList = entry->next;
    if(entry->timersCallBack)
    {
      entry->timersCallBack(entry, entry->userdata);
    }
  }
  return 1;
}